# -*- coding: utf-8 -*-

from pprint import pprint
from unittest import TestCase
from yarn_api_client.node_manager import NodeManager
from yarn_api_client.errors import IllegalArgumentError


class NodeManagerIntegrationTestCase(TestCase):

    def setUp(self):
                                                       #https://lresende-iop-cluster:8443/gateway/default/resourcemanager/v1/cluster
        self.nodeManager = NodeManager(serviceEndpoint='http://172.16.173.104:8042/ws/v1/node',
                                  username='guest',
                                  password='guest-password')

    def test_node_information(self):
        info = self.nodeManager.node_information()
        pprint(info.data)
        self.assertEqual(info.data['nodeInfo']['nodeHealthy'], 'true')

    def test_node_applications(self):
        self.nodeManager.node_applications('RUNNING', 'root')
        request_mock.assert_called_with('/ws/v1/node/apps',
                                        state='RUNNING', user='root')

        self.nodeManager.node_applications()
        request_mock.assert_called_with('/ws/v1/node/apps')

        with self.assertRaises(IllegalArgumentError):
            self.nodeManager.node_applications('ololo', 'root')

    def test_node_application(self):
        self.nodeManager.node_application('app_1')
        request_mock.assert_called_with('/ws/v1/node/apps/app_1')

    def test_node_containers(self):
        self.nodeManager.node_containers()
        request_mock.assert_called_with('/ws/v1/node/containers')

    def test_node_container(self):
        self.nodeManager.node_container('container_1')
        request_mock.assert_called_with('/ws/v1/node/containers/container_1')
