# -*- coding: utf-8 -*-
try:
    from unittest2 import TestCase
except ImportError:
    from unittest import TestCase
